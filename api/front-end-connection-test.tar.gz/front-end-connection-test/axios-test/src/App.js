import logo from './logo.svg';
import axios from 'axios';
import './App.css';

function App() {
    const apiUrl = 'http://localhost:8080/api/stock/products';

    axios.get(apiUrl)
        .then(response => {
            console.log('Resultados da API:', response.data);
        })
        .catch(error => {
            console.error('Erro na solicitação à API:', error);
        });

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
